package act9;

public class GatPersa {

    public void aixecat(){
        System.out.println("-> ok, boomer me estoy levantando");
    }

    public void seu(){
        System.out.println("-> me he sentado");
    }

    public void estirat(){
        System.out.println("-> me estoy estirando, uuuh que descanso *bebe leche*");
    }

    public void test(){
        System.out.println("-> he caido de pies jejeje!!!, soy un gato que te pensabas?");
    }

}